<template>
    <div id="app">
        <router-view :key="$route.fullPath"/>
    </div>
</template>

<script>
export default {
    name: "App"
};
</script>

<style>
#app {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}
</style>
