'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"https://tp.cec.org.cn/jeecg-boot"'
//   BASE_API: '"http://211.160.78.147:8080/jeecg-boot"'
    // BASE_API: '"http://172.18.5.53:8080/jeecg-boot"'
}
